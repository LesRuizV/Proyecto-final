<!DOCTYPE html>
<html>
<head>
<style>
   .mi-tabla {
  width: 150%;
  height: 300px;
  border-collapse: collapse;

}
 .mi-tabla th, .mi-tabla td {
  padding: 10px;
  text-align: center;
  border: 1px solid #fff;
  color: #fff; 
}



</style>
</head>
<body>
  
  <?php
  require_once 'conexion.php';

  try {
      // Obtener los autores$autores de la base de datos
      $stmt = $conn->query("SELECT apellido, nombre, pais FROM autores");
      $autores = $stmt->fetchAll(PDO::FETCH_ASSOC);
  } catch (PDOException $e) {
      echo "Error al obtener los autores: " . $e->getMessage();
  }
  
  // Cerrar la conexión
  $conn = null;
  ?>
  
    <section class="table_section layout_padding">
      <div class="container">
          <div class="row d-flex justify-content-center">
              <div class="menu-content pb-60 col-lg-9">
                  <div class="title text-center">
                      <h1 class="mb-10">Nuestros Autores</h1>
                      <br>
                      
                  </div>
              </div>
          </div>
  
          <div class="row">
              <div class="col-lg-12">
                  <table class="table table-bordered mi-tabla">
                      <thead>
                          <tr>
                              <th>Apellido</th>
                              <th>Nombre</th>
                              <th>País</th>
                         
                          </tr>
                      </thead>
                      <tbody>
                          <?php foreach ($autores as $autor) : ?>
                              <tr>
                                  <td><?= $autor['apellido'] ?></td>
                                  <td><?= $autor['nombre'] ?></td>
                                  <td><?= $autor['pais'] ?></td>
                                
                              </tr>
                          <?php endforeach; ?>
                      </tbody>
                  </table>
              </div>
          </div>
        </div>
      </section>

</body>
</html>



<?php
