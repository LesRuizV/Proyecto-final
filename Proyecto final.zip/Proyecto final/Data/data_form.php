<?php
// Obtener los datos del formulario
$fecha = $_POST['fecha'];
$correo = $_POST['correo'];
$nombre = $_POST['nombre'];
$asunto = $_POST['asunto'];
$comentario = $_POST['comentario'];

// Incluir el archivo de conexión a la base de datos
require_once 'conexion.php';

try {
    // Preparar la consulta para insertar los datos en la tabla utilizando consultas preparadas
    $sql = "INSERT INTO contacto (fecha, correo, nombre, asunto, comentario) VALUES (:fecha, :correo, :nombre, :asunto, :comentario)";
    $stmt = $conn->prepare($sql);

    // Vincular los parámetros
    $stmt->bindParam(':fecha', $fecha);
    $stmt->bindParam(':correo', $correo);
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':asunto', $asunto);
    $stmt->bindParam(':comentario', $comentario);

    // Ejecutar la consulta
    $stmt->execute();

    echo "<div class='alert alert-success' role='alert'>
        Los datos se han guardado correctamente.
    </div>";
} catch (PDOException $e) {
    echo "<div class='alert alert-danger' role='alert'>
        Error al guardar los datos: " . $e->getMessage() . "
    </div>";
}

// Cerrar la conexión
$conn = null;
?>